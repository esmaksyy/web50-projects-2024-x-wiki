#Kabak



Kabak is Esma's dog